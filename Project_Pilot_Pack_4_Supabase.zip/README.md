# Project Pilot Pack 4 — Supabase

This pack replaces demo browser accounts and projects with real Supabase authentication and persistent projects.

## 1. Run the database setup

In Supabase:

1. Open SQL Editor.
2. Click New query.
3. Open `supabase/schema.sql` from this pack.
4. Copy the entire file into the query.
5. Click Run.

## 2. Upload to GitHub

Replace or add:

- `package.json`
- `lib/supabase.js`
- `app/login/page.js`
- `app/login/login.css`
- `app/dashboard/page.js`
- `app/dashboard/dashboard.css`

Do not upload `supabase/schema.sql` to the app folder. It may stay in the repository under `supabase/` for reference.

## 3. Deploy

Commit the files. Vercel will install `@supabase/supabase-js` and redeploy.

## 4. Test

1. Visit `/login`.
2. Create an account.
3. Check email confirmation if Supabase requires it.
4. Sign in.
5. Open `/dashboard`.
6. Click New Project.
7. Refresh and verify the project remains saved.

## Security

The publishable key is intended for browser use. Row Level Security in `schema.sql` prevents users from viewing or editing another user's projects.

Never place a Supabase secret key or service-role key in browser code or GitHub.
