import './globals.css';

export const metadata = {
  title: 'Project Pilot',
  description: 'Address-based home project and permit guidance.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
