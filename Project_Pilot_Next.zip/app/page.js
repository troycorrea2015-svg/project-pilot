'use client';

import { useState } from 'react';

const PROJECTS = [
  'Fence',
  'Deck',
  'Shed',
  'Roof replacement',
  'HVAC replacement',
  'Kitchen remodel',
  'Bathroom remodel'
];

export default function Home() {
  const [form, setForm] = useState({
    address: '',
    zip: '',
    project: 'Fence',
    description: ''
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  function update(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
  }

  async function submit(event) {
    event.preventDefault();
    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('/api/lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });

      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('The lookup service returned an unexpected response.');
      }

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Lookup failed.');
      setResult(data);
      setTimeout(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' }), 50);
    } catch (err) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <header className="nav">
        <div className="brand"><span className="logo">P</span><span>Project Pilot</span></div>
        <a className="navButton" href="#planner">Start a project</a>
      </header>

      <section className="hero">
        <div>
          <span className="eyebrow">PLAN • PERMIT • BUILD</span>
          <h1>Your home project, mapped from the start.</h1>
          <p>
            Enter a property address and project type. Project Pilot verifies the address,
            identifies a supported Delaware permitting area, and shows official links,
            application steps, and documents to prepare.
          </p>
          <a className="primary" href="#planner">Build my roadmap</a>
        </div>
        <div className="heroCard">
          <span>PROJECT ROADMAP</span>
          <h3>From address to next steps</h3>
          <div className="miniStep"><b>1</b><div><strong>Verify address</strong><small>Match the property location</small></div></div>
          <div className="miniStep"><b>2</b><div><strong>Identify authority</strong><small>City, town, or county</small></div></div>
          <div className="miniStep"><b>3</b><div><strong>Open official sources</strong><small>Applications, zoning, and contacts</small></div></div>
          <div className="miniStep"><b>4</b><div><strong>Prepare the project</strong><small>Documents and next actions</small></div></div>
        </div>
      </section>

      <section className="plannerSection" id="planner">
        <div className="heading">
          <span className="eyebrow">START HERE</span>
          <h2>Build your project roadmap</h2>
          <p>The first live data release supports starter records for Milford, Dover, and Sussex County.</p>
        </div>

        <form className="planner" onSubmit={submit}>
          <label>
            Property address
            <input name="address" value={form.address} onChange={update} placeholder="10 NW Front Street" required />
          </label>
          <label>
            ZIP code
            <input name="zip" value={form.zip} onChange={update} placeholder="19963" maxLength="5" inputMode="numeric" required />
          </label>
          <label>
            Project type
            <select name="project" value={form.project} onChange={update}>
              {PROJECTS.map((project) => <option key={project}>{project}</option>)}
            </select>
          </label>
          <label className="wide">
            Project description
            <textarea name="description" value={form.description} onChange={update} placeholder="Example: six-foot privacy fence along the rear and side property lines." />
          </label>
          <button className="primary wide" type="submit" disabled={loading}>
            {loading ? 'Checking address and sources…' : 'Build my project roadmap'}
          </button>
          {error && <p className="error wide">{error}</p>}
        </form>
      </section>

      {result && (
        <section className="results" id="results">
          <div className="resultTop">
            <div>
              <span className="eyebrow">YOUR PROJECT PILOT ROADMAP</span>
              <h2>{result.title}</h2>
              <p>{result.summary}</p>
            </div>
            <div className="jurisdiction">
              <small>Likely governing area</small>
              <strong>{result.jurisdiction}</strong>
              <span>{result.county}</span>
              {result.matchedAddress && <span>Matched: {result.matchedAddress}</span>}
            </div>
          </div>

          <div className="notice">
            <strong>Important:</strong> This is preliminary guidance. Confirm final requirements,
            fees, and approvals with the governing authority before beginning work.
          </div>

          <div className="resultGrid">
            <article>
              <h3>Recommended next steps</h3>
              <ol className="steps">
                {result.steps.map((step, index) => (
                  <li key={step}><span>{index + 1}</span><p>{step}</p></li>
                ))}
              </ol>
            </article>

            <aside>
              <section className="panel">
                <h3>Documents to prepare</h3>
                <ul>{result.documents.map((item) => <li key={item}>✓ {item}</li>)}</ul>
              </section>
              <section className="panel">
                <h3>Verified local facts</h3>
                <ul>{result.facts.map((item) => <li key={item}>✓ {item}</li>)}</ul>
              </section>
              <section className="panel">
                <h3>Official links</h3>
                <div className="links">
                  {result.sources.map((source) => (
                    <a key={source.url} href={source.url} target="_blank" rel="noreferrer">{source.label} ↗</a>
                  ))}
                </div>
              </section>
            </aside>
          </div>
        </section>
      )}

      <footer>
        <div className="brand"><span className="logo">P</span><span>Project Pilot</span></div>
        <p>Plan smarter. Build with confidence.</p>
      </footer>
    </main>
  );
}
