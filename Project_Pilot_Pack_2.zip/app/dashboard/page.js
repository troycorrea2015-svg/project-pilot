"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import "./dashboard.css";

const starterProjects = [
  {
    id: 1,
    title: "Backyard Deck",
    location: "Milford, Delaware",
    status: "Permit Research",
    progress: 42,
    nextStep: "Confirm setback requirements",
  },
  {
    id: 2,
    title: "Kitchen Remodel",
    location: "Draft project",
    status: "Planning",
    progress: 18,
    nextStep: "Add dimensions and project photos",
  },
];

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState(starterProjects);

  useEffect(() => {
    const saved = localStorage.getItem("projectPilotUser");
    if (!saved) {
      router.push("/login");
      return;
    }
    setUser(JSON.parse(saved));

    const savedProjects = localStorage.getItem("projectPilotProjects");
    if (savedProjects) setProjects(JSON.parse(savedProjects));
  }, [router]);

  const averageProgress = useMemo(() => {
    if (!projects.length) return 0;
    return Math.round(
      projects.reduce((sum, project) => sum + project.progress, 0) /
        projects.length
    );
  }, [projects]);

  function addProject() {
    const project = {
      id: Date.now(),
      title: "New Home Project",
      location: "Location not added",
      status: "Getting Started",
      progress: 5,
      nextStep: "Describe the project you are planning",
    };

    const updated = [project, ...projects];
    setProjects(updated);
    localStorage.setItem("projectPilotProjects", JSON.stringify(updated));
  }

  function signOut() {
    localStorage.removeItem("projectPilotUser");
    router.push("/login");
  }

  if (!user) {
    return <main className="dashboardLoading">Opening your projects…</main>;
  }

  return (
    <main className="dashboardPage">
      <aside className="dashboardSidebar">
        <a href="/" className="dashboardBrand">
          <span>P</span>
          <strong>Project Pilot</strong>
        </a>

        <nav>
          <a className="active" href="/dashboard">Overview</a>
          <a href="#projects">My Projects</a>
          <a href="#documents">Documents</a>
          <a href="#professionals">Professionals</a>
          <a href="/">Project Pilot Home</a>
        </nav>

        <div className="sidebarUser">
          <div>{user.name.charAt(0).toUpperCase()}</div>
          <span>
            <strong>{user.name}</strong>
            <small>{user.role}</small>
          </span>
        </div>
      </aside>

      <section className="dashboardMain">
        <header className="dashboardHeader">
          <div>
            <p>PROJECT WORKSPACE</p>
            <h1>Welcome back, {user.name}.</h1>
            <span>Here is what needs your attention next.</span>
          </div>

          <div className="dashboardActions">
            <button className="signOutButton" onClick={signOut}>Sign Out</button>
            <button className="newProjectButton" onClick={addProject}>
              + New Project
            </button>
          </div>
        </header>

        <div className="summaryGrid">
          <article>
            <span>Active Projects</span>
            <strong>{projects.length}</strong>
            <small>Projects currently being planned</small>
          </article>
          <article>
            <span>Overall Progress</span>
            <strong>{averageProgress}%</strong>
            <small>Average readiness across projects</small>
          </article>
          <article>
            <span>Next Priority</span>
            <strong>Permit Review</strong>
            <small>Verify local project requirements</small>
          </article>
        </div>

        <section className="dashboardSection" id="projects">
          <div className="sectionTitleRow">
            <div>
              <p>MY PROJECTS</p>
              <h2>Continue where you left off.</h2>
            </div>
            <button onClick={addProject}>Add Project</button>
          </div>

          <div className="projectGrid">
            {projects.map((project) => (
              <article className="projectCard" key={project.id}>
                <div className="projectTop">
                  <div className="projectIcon">P</div>
                  <span>{project.status}</span>
                </div>
                <h3>{project.title}</h3>
                <p>{project.location}</p>

                <div className="progressLabel">
                  <span>Project readiness</span>
                  <strong>{project.progress}%</strong>
                </div>
                <div className="dashboardProgress">
                  <span style={{ width: `${project.progress}%` }} />
                </div>

                <div className="nextStep">
                  <small>NEXT STEP</small>
                  <strong>{project.nextStep}</strong>
                </div>

                <button>Open Project</button>
              </article>
            ))}
          </div>
        </section>

        <section className="workspaceGrid">
          <article id="documents">
            <p>PROJECT BINDER</p>
            <h3>Keep every important document together.</h3>
            <span>
              Permits, estimates, contracts, receipts, inspection reports, and
              warranties will live here.
            </span>
            <button>Add a Document</button>
          </article>

          <article id="professionals">
            <p>PROFESSIONALS</p>
            <h3>Find the right help for the work ahead.</h3>
            <span>
              Compare contractors by specialty, service area, and verified
              credentials.
            </span>
            <button>Browse Professionals</button>
          </article>
        </section>
      </section>
    </main>
  );
}
