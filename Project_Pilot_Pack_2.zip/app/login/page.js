"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import "./login.css";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    const displayName =
      mode === "signup" && name.trim()
        ? name.trim()
        : email.split("@")[0] || "Project Pilot User";

    localStorage.setItem(
      "projectPilotUser",
      JSON.stringify({
        name: displayName,
        email,
        role: "Homeowner",
      })
    );

    router.push("/dashboard");
  }

  return (
    <main className="loginPage">
      <section className="loginBrandPanel">
        <a href="/" className="loginBrand">
          <span>P</span>
          <strong>Project Pilot</strong>
        </a>

        <div>
          <p className="loginEyebrow">YOUR PROJECTS, ORGANIZED</p>
          <h1>Keep every project moving in one clear direction.</h1>
          <p>
            Save your ideas, permit research, project photos, documents, tasks,
            and contractor conversations in one place.
          </p>

          <div className="loginHighlights">
            <span>✓ Save project progress</span>
            <span>✓ Return to your roadmap anytime</span>
            <span>✓ Keep documents and decisions together</span>
          </div>
        </div>

        <small>
          Project Pilot helps you plan with clarity and move forward with confidence.
        </small>
      </section>

      <section className="loginFormPanel">
        <div className="loginCard">
          <div className="loginTabs">
            <button
              className={mode === "signin" ? "active" : ""}
              onClick={() => setMode("signin")}
              type="button"
            >
              Sign In
            </button>
            <button
              className={mode === "signup" ? "active" : ""}
              onClick={() => setMode("signup")}
              type="button"
            >
              Create Account
            </button>
          </div>

          <div className="loginHeading">
            <h2>{mode === "signin" ? "Welcome back." : "Create your workspace."}</h2>
            <p>
              {mode === "signin"
                ? "Open your projects and continue where you left off."
                : "Start saving projects, ideas, and next steps."}
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            {mode === "signup" && (
              <label>
                Name
                <input
                  type="text"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Your name"
                  required
                />
              </label>
            )}

            <label>
              Email address
              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                required
              />
            </label>

            <label>
              Password
              <input
                type="password"
                placeholder="Enter your password"
                minLength="6"
                required
              />
            </label>

            <button className="loginSubmit" type="submit">
              {mode === "signin" ? "Open My Projects" : "Create My Account"}
            </button>
          </form>

          <p className="demoNote">
            This version creates a local demo account in your browser. Secure
            Supabase authentication will replace it in the next backend update.
          </p>

          <a href="/" className="backHome">← Back to homepage</a>
        </div>
      </section>
    </main>
  );
}
