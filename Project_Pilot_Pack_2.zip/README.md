# Project Pilot Pack 2

This pack adds two features:

1. Login / account entry
2. Project dashboard

It also includes a small homepage update that:
- adds a Login link
- changes the top button to Open My Projects
- gives Project Pilot a warmer, more confident personality

## Upload

Upload these paths into the repository:

- `app/page.js` (replace existing)
- `app/login/page.js`
- `app/login/login.css`
- `app/dashboard/page.js`
- `app/dashboard/dashboard.css`

Do not replace:
- `package.json`
- `app/layout.js`
- `app/globals.css`
- `app/page.css`
- any API route

## Test

1. Open `/login`
2. Create an account or sign in
3. You should be sent to `/dashboard`
4. Add a project
5. Refresh the page and confirm the demo session remains in that browser

This is a local demo account system. Secure Supabase authentication comes in a later backend pack.
