# Project Pilot Pack 3

Upload and replace `app/page.js`.

Add `app/api/chat/route.js` and `app/api/address/route.js`.

Copy the contents of `app/chat-update.css` to the bottom of your existing `app/page.css`.

In Vercel, optionally add `OPENAI_API_KEY` and `OPENAI_MODEL=gpt-5-mini` under Settings -> Environment Variables, then redeploy. Never upload the API key to GitHub. Without a key, the built-in conversation and Census address verification still work.
