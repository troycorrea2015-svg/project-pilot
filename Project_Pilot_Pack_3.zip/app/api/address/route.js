import { NextResponse } from "next/server";
export async function POST(request) {
  try {
    const { address = "" } = await request.json();
    if (!address.trim()) return NextResponse.json({ error: "A full property address is required." }, { status: 400 });
    const url = "https://geocoding.geo.census.gov/geocoder/geographies/onelineaddress" + `?address=${encodeURIComponent(address)}` + "&benchmark=Public_AR_Current&vintage=Current_Current&format=json";
    const response = await fetch(url, { headers: { "User-Agent": "ProjectPilot/1.0" }, cache: "no-store" });
    if (!response.ok) throw new Error();
    const data=await response.json();
    const match=data?.result?.addressMatches?.[0];
    if (!match) return NextResponse.json({ matched:false, message:"The address could not be matched. Include street, city, state, and ZIP code." }, { status:404 });
    return NextResponse.json({ matched:true, matchedAddress:match.matchedAddress, coordinates:match.coordinates||null, components:match.addressComponents||null, geographies:match.geographies||null });
  } catch {
    return NextResponse.json({ error:"The address could not be verified right now." }, { status:500 });
  }
}
