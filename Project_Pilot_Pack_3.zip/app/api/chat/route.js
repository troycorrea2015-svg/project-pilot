import { NextResponse } from "next/server";

function latestUserMessage(messages = []) {
  return [...messages].reverse().find((message) => message.role === "user")?.text || "";
}

function looksLikeAddress(text) {
  return /\d{1,6}\s+.+\b(st|street|rd|road|ave|avenue|dr|drive|ln|lane|ct|court|blvd|way|pike|hwy|highway)\b/i.test(text) || /\b\d{5}(?:-\d{4})?\b/.test(text);
}

async function verifyAddress(address) {
  const url = "https://geocoding.geo.census.gov/geocoder/locations/onelineaddress" + `?address=${encodeURIComponent(address)}` + "&benchmark=Public_AR_Current&format=json";
  const response = await fetch(url, { headers: { "User-Agent": "ProjectPilot/1.0" }, cache: "no-store" });
  if (!response.ok) return null;
  const data = await response.json();
  const match = data?.result?.addressMatches?.[0];
  if (!match) return null;
  return { matchedAddress: match.matchedAddress, city: match.addressComponents?.city || "", state: match.addressComponents?.state || "", zip: match.addressComponents?.zip || "", coordinates: match.coordinates || null };
}

function localResponse(messages, address) {
  const userMessages = messages.filter((message) => message.role === "user");
  const latest = latestUserMessage(messages);
  if (address) return { title: "Great — I found the property.", text: "Now tell me the details that will shape the plan: approximate dimensions, preferred materials, budget range, target timing, and whether you expect to hire a contractor or complete some of the work yourself.", address };
  if (userMessages.length === 1) return { title: "That gives us a strong starting point.", text: "What is the full property address? I’ll use it to check the location and prepare the correct jurisdiction and permit path." };
  if (looksLikeAddress(latest)) return { title: "I couldn’t confirm that address yet.", text: "Please enter the full street address, city, state, and ZIP code. I’ll keep the rest of your project conversation right here." };
  return { title: "Your project is taking shape.", text: "I’ve saved those details in this conversation. Add anything else that matters—materials, layout, priorities, budget, or timing—and I’ll continue organizing the roadmap." };
}

function extractOutputText(result) {
  if (result.output_text) return result.output_text;
  const parts=[];
  for (const item of result.output || []) for (const content of item.content || []) if (typeof content.text === "string") parts.push(content.text);
  return parts.join("").trim();
}

export async function POST(request) {
  try {
    const { messages = [] } = await request.json();
    const latest = latestUserMessage(messages);
    const address = looksLikeAddress(latest) ? await verifyAddress(latest) : null;
    if (!process.env.OPENAI_API_KEY) return NextResponse.json(localResponse(messages, address));
    const conversation = messages.map((m) => `${m.role.toUpperCase()}: ${m.text}`).join("\n");
    const prompt = `You are Project Pilot, a capable and welcoming project-planning assistant. Be friendly, confident, practical, and lightly conversational—never bland, robotic, childish, or overly emotional. Sound like an experienced project manager who is easy to work with. Ask one focused follow-up question at a time. Remember the full conversation. Never invent permit rules, fees, codes, timelines, contractors, or official requirements. Current verified address: ${address ? JSON.stringify(address) : "none"}. Conversation:
${conversation}
Return only JSON: {"title":"short warm heading","text":"helpful response and one focused next question"}`;
    const apiResponse = await fetch("https://api.openai.com/v1/responses", { method: "POST", headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-5-mini", input: prompt }) });
    if (!apiResponse.ok) return NextResponse.json(localResponse(messages, address));
    const result=await apiResponse.json();
    const text=extractOutputText(result).replace(/^```json\s*/i,"").replace(/```$/i,"").trim();
    const parsed=JSON.parse(text);
    return NextResponse.json({ title: parsed.title, text: parsed.text, address });
  } catch {
    return NextResponse.json({ error: "Project Pilot could not process that message." }, { status: 500 });
  }
}
