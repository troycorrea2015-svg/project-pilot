# Project Pilot — Live AI Update

This update adds a secure Vercel Function at `api/roadmap.js`.

## Upload this update to GitHub

1. Open your `project-pilot` repository.
2. Choose **Add file → Upload files**.
3. Upload:
   - the `api` folder
   - `app.js`
   - `README.md`
4. If `vercel.json` still exists in the repository, delete it.
5. Commit the changes to `main`.

## Activate live AI in Vercel

1. Open the Project Pilot project in Vercel.
2. Go to **Settings → Environment Variables**.
3. Add:
   - Name: `OPENAI_API_KEY`
   - Value: your OpenAI API key
   - Environments: Production and Preview
   - Mark it Sensitive when available.
4. Optional:
   - Name: `OPENAI_MODEL`
   - Value: `gpt-4.1-mini`
5. Save.
6. Open **Deployments** and redeploy the latest production deployment.

Do not put the API key in GitHub, `app.js`, `index.html`, or any public file.

## Current accuracy boundary

The AI generates preliminary planning guidance. The official source registry is intentionally empty until each municipality or county is researched and verified. This prevents the system from inventing regulations, fees, code sections, or government links.
